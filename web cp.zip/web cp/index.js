let submitbtn=document.getElementById("submit");
submitbtn.addEventListener("click",function(){
    let name=document.getElementById("name").value;
    let fname=document.getElementById("fname").value;
    let gender=document.getElementById("gender").value;
    let mobnum=document.getElementById("Mnum").value;
    console.log(name);
    console.log(fname);
    console.log(gender);
    console.log(mobnum);
    let showdata=document.getElementById("show");
    showdata.target="_blank"
    showdata.innerHTML=`<b>${name}</b> is son of <b>${fname}</b><br>
    he is a  <b>${gender}</b><br>
     his mobile number is <b>${mobnum}</b><br>`




})