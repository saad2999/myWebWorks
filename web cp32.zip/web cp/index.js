const calculator={
    number1:0,
    number1:0,
    operator: '+',
    result: 0,
    plus: function()
    {
        result = number1 + number2;
    },
    minus: function()
    {
        result = number1 - number2;
    },
    mul: function()
    {
        result = number1 * number2;
    },
    div: function()
    {
        result = number1 / number2;
    }
}